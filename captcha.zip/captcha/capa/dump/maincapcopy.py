
import pytesseract

import numpy as np
from PIL import Image
import cv2
#from matplotlib import pyplot
#from PIL import Image, ImageFilter
from skimage.measure import compare_ssim
pytesseract.pytesseract.tesseract_cmd = 'C:\\Program Files\\Tesseract-OCR\\tesseract.exe'
sav='C:\\Users\\vk779\\Desktop\\captcha\\cap\\'

def im2tx(grayA):
    lis="123456789ABCDEFGHIJKLMNPQRSTUVWXYZ"
    temp=0
    for x in lis:
        imageB = "C:/Users/vk779/Desktop/captcha/capa/"+x+".jpg"
        #print(imageB)
        grayB = cv2.imread(imageB)
        grayB = cv2.cvtColor(grayB, cv2.COLOR_BGR2GRAY)
        (score, diff) = compare_ssim(grayA, grayB, full=True)
        diff = (diff * 255).astype("uint8")
        if(temp < score):
            temp= score
            ans=x
    print(ans)
def image2txt(path):
    a = cv2.imread(path) 
    a= cv2.cvtColor(a, cv2.COLOR_BGR2GRAY)
    #print("ORIGINAL BLACK AND WHITE")
    #ax=Image.fromarray(a)
    #pyplot.imshow(ax)
    #pyplot.show()
    #ax.save("aaaaa.jpg")
    for i in range(45):
        for j in range(180):
            if(a[i][j]!= 0 and a[i][j]!= 255 ):
                a[i][j]=255
            if(j%30==0 and a[i][j]==0):
                a[i][j]=255 #255 us for white
                for x in range(5):
                    if((j-x)>=0):
                        a[i][j-x]=255
   # print("REMOVING LINES USING GRADIENT")
   # ax=Image.fromarray(a)
   # pyplot.imshow(ax)
   # text = pytesseract.image_to_string(ax, config = "\-c tessedit_char_whitelist= 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ -psm 6 --oem 0")
   # print(text)
   # pyplot.show()
    #ax.save("aaaaa.jpg")
   # print("REMOVING SINGLE PIXELS")
    for i in range(45):
        for j in range(180):           
            if(a[i][j]==0):
                if(i!=0 and j!=0 and i!=44 and j!=179):
                    if(a[i+1][j] ==255 and a[i+1][j+1]==255):
                        if( a[i-1][j] ==255 and a[i][j-1] ==255 and a[i][j+1]==255):
                           # a[i][j]=255
                            if(a[i+1][j-1] ==255 and a[i-1][j+1] ==255 and a[i-1][j-1]==255):
                                a[i][j]=255
                                #print(i,j,sep="-",end=" 
    #ax=Image.fromarray(a)
    #pyplot.imshow(ax)
    
    #text = pytesseract.image_to_string(ax, config = "\-c tessedit_char_whitelist= 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ -psm 6 --oem 0")
    #print(text)
    #pyplot.show()

    #figure_size = 1 # the dimension of the x and y axis of the kernal.
    c = (2, 2) 
    new_image = cv2.blur(a,c)
    #new_image= Image.fromarray(new_image)
    #new_image=Image.fromarray(image)
    #new_image.save('result.png')
    #a = np.array(Image.open('result.png').convert('L'))
    a= np.asarray(new_image)
    #print(a.size)
    
    #a= np.asarray(a)
    #print(a.flags)
    #a.setflags(write=1)
    #print(a.size)
    #print("MEDIAN BLUR")
    #ax=Image.fromarray(a)
    #pyplot.imshow(ax)
    #pyplot.show()
    #ax.save("aaaaa.jpg")
    
    '''
    for i in range(45):
        for j in range(180):
            if(a[i][j]!= 0 and a[i][j]!= 255 ):
                a[i][j]=255
            if(j%30==0 and a[i][j]==0):
                a[i][j]=255 #255 us for white
                for x in range(5):
                    if((j-x)>=0):
                        a[i][j-x]=255
    '''
    #print("MAKING WEAK PIXELS STRONG AND REMOVING LOWER LINES")
    for i in range(45):
        for j in range(180):           
            if(a[i][j]<255):
                if( i!=44 and j!=179):
                    if(a[i+1][j] >0 and a[i+1][j+1]>0):
                        if( a[abs(i-1)][j]>0 and a[i][abs(j-1)] >0 and a[i][j+1]>0):
                           # a[i][j]=255
                            if(a[i+1][abs(j-1)]>0 and a[abs(i-1)][j+1]>0 and a[abs(i-1)][j-1]>0):
                                a[i][j]=255
                                #print(i,j,sep="-",end=" ")
                if(i>44 or j>177):
                    a[i][j]=255
    for i in range(45):
        for j in range(180):
            if(a[i][j]<255):
                a[i][j]=0
                
                
    aa=Image.fromarray(a)
    #kernel = np.array([[-2,-2,-2], [-1,9,-1], [-1,-1,-1]])
    #kernel = np.array([[0,0,0], [-1,9,-1], [-1,-1,-1]])
    #ax=Image.fromarray(a)
    #pyplot.imshow(ax)
    #pyplot.show()
    #ax.save("aaaaa.jpg")

    #aa.save("vian.jpg")
    #text = pytesseract.image_to_string(aa, lang = 'eng')
    text = pytesseract.image_to_string(aa, config = "\-c tessedit_char_whitelist= 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ -psm 6 --oem 0")
   # print(text)
    ad=0
    #print(text)
    for i in range(0,179,30):
        s= a[10:45, i:i+30]
        global xmc

        try:
            name= sav+text[ad]+ "-"+str(xmc)+"-"+str(ad)+".jpg"
            aaa=Image.fromarray(s)
            aaa.save(name)
        except:
            name= sav+ "misc"+ "-"+str(xmc)+"-" +str(ad)+ ".jpg"
            aaa=Image.fromarray(s)
            aaa.save(name)
        ad=ad+1
        #pyplot.imshow(aaa)
        #pyplot.show()
        #xa= str(i) + ".jpg"
        #aaa.save(xa)
        #text = pytesseract.image_to_string(aaa,  config = "\-c tessedit_char_whitelist= 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ -psm 6 --oem 0")
        #print(text)
    #print("d")
    #pyplot.show()
#from os import listdir
#from os.path import isfile, join
#mypath="C:\\Users\\vk779\\Desktop\\captcha\\"
##path = [f for f in listdir(mypath) if isfile(join(mypath, f))]
##
##
#path=(('C:\\Users\\vk779\\Desktop\\captcha\\download ('))
##for z in path :
#z='1'
#z=mypath+z
##    print(z)
#    '''    
#    print("REMOVING DUAL PIXELS")
#    for i in range(2,44,3):
#        for j in range(2,179,3):
#            count=0
#            for x in range(i,i+3,1):
#                for y in range(j,j+3,1):
#                    if(a[x][y]==0):
#                        count=count+1
#                    if(a[x-2][y-2]==0):
#                        count=count+1
#                    
#            if(count<1):
#                for x in range(i,i+3,1):
#                    for y in range(j,j+3,1):
#                        a[x][y]=255
#                        #print(".",end="")
#                                
#                                
#                
#                                #print(i,j,sep="-",end=" ")                
#    ax=Image.fromarray(a)
#    text = pytesseract.image_to_string(ax, lang = 'eng')
#    print(text)
#
#    pyplot.imshow(ax)
#    pyplot.show()
#    #ax.save("aaaaa.jpg")
#    text = pytesseract.image_to_string(ax, lang = 'eng')
#    print(text) 
#'''
xc=6500
xmc=0
for i in range(xc):
    z='C:\\Users\\vk779\\Desktop\\captcha\\cap-'+str(i) +'.jpg'
    image2txt(z) 
    xmc=xmc+1
    print(xmc)