import time
import random
import numpy as np
import os
import cv2
from matplotlib import pyplot
from skimage.measure import compare_ssim


def im2tx(grayA):
    lis="123456789ABCDEFGHIJKLMNPQRSTUVWXYZ"
    temp=0
    for x in lis:
        imageB="data/"+x+".jpg"
        grayB = cv2.imread(imageB,0)
        (score, diff) = compare_ssim(grayA, grayB, full=True)
        if(temp < score):
            temp= score
            ans=x
    return ans
    
def image2txt(path=(os.getcwd()+"\0.png"),show=False):
    a = cv2.imread(path) 
    
    if(show == True):
        pyplot.imshow(a)
        pyplot.show()
    a= cv2.cvtColor(a, cv2.COLOR_BGR2GRAY)
    for i in range(45):
        for j in range(180):
            if(a[i][j]!= 0 and a[i][j]!= 255 ):
                a[i][j]=255
            if(j%30==0 and a[i][j]==0):
                a[i][j]=255 #255 us for white
                for x in range(5):
                    if((j-x)>=0):
                        a[i][j-x]=255

    for i in range(45):
        for j in range(180):           
            if(a[i][j]==0):
                if(i!=0 and j!=0 and i!=44 and j!=179):
                    if(a[i+1][j] ==255 and a[i+1][j+1]==255):
                        if( a[i-1][j] ==255 and a[i][j-1] ==255 and a[i][j+1]==255):
                            if(a[i+1][j-1] ==255 and a[i-1][j+1] ==255 and a[i-1][j-1]==255):
                                a[i][j]=255

    c = (2, 2) 
    new_image = cv2.blur(a,c)

   
    a= np.asarray(new_image)

    for i in range(45):
        for j in range(180):           
            if(a[i][j]<255):
                if( i!=44 and j!=179):
                    if(a[i+1][j] >0 and a[i+1][j+1]>0):
                        if( a[abs(i-1)][j]>0 and a[i][abs(j-1)] >0 and a[i][j+1]>0):
                           # a[i][j]=255
                            if(a[i+1][abs(j-1)]>0 and a[abs(i-1)][j+1]>0 and a[abs(i-1)][j-1]>0):
                                a[i][j]=255
                                #print(i,j,sep="-",end=" ")
                if(i>44 or j>177):
                    a[i][j]=255
    for i in range(45):
        for j in range(180):
            if(a[i][j]<255):
                a[i][j]=0

#    if(show == True):
#        ax=Image.fromarray(a)
#        pyplot.imshow(ax)
#        pyplot.show()
    data=""
    for i in range(0,179,30):
        s= a[10:45, i:i+30]
        data=data+im2tx(s)
    return data


start_time = time.time()
    
z=input("Enter File Name:-")
print(image2txt(z))

print()
print("--- %s seconds ---" % (time.time() - start_time))    
  
print("Made by Vinc3nt all rights reserved" )
