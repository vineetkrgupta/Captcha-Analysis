# -*- coding: utf-8 -*-
from selenium import webdriver
import base64
import time
from selenium.webdriver.chrome.options import Options


chrome_options = Options()
chrome_options.add_argument("--headless")
chrome_options.add_argument("--window-size=1920x1080")
chrome_options.add_argument("--disable-notifications")
chrome_options.add_argument('--no-sandbox')
chrome_options.add_argument('--verbose')
chrome_options.add_experimental_option("prefs", {
        "download.default_directory": "<path_to_download_default_directory>",
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing_for_trusted_sources_enabled": False,
        "safebrowsing.enabled": False
})
chrome_options.add_argument('--disable-gpu')
chrome_options.add_argument('--disable-software-rasterizer')

b=0
x=0
driver =webdriver.Chrome(chrome_options=chrome_options , executable_path="C:/Users/vk779/Downloads/Compressed/chromedriver.exe")
driver.implicitly_wait(30)
driver.get("http://myerp.vitbhopal.ac.in:8080/vtop/initialProcess")
driver.find_element_by_link_text("Login to VTOP").click()
driver.find_element_by_xpath("//button[@type='submit']").click()
driver.find_element_by_xpath("//div[@id='captchaRefresh']/div/button/img").click()
while(1):
    #driver.find_element_by_xpath("//div[@id='captchaRefresh']/div/button/img").click()
    try:
        logo = driver.find_element_by_xpath("//html//body[@class='VTopBody']//div[@id='page_outline']//div[@id='page-wrapper']//section[@id='loginbox']//div[@class='box box-info']//div[@class='box-body']//form[@id='form-signin_v1']//div[3]//div[@id='captchaRefresh']//div[@class='col-md-offset-1']//img")
        logo= logo.get_attribute("src")
        logo=logo[22:]
        imgdata = base64.b64decode(logo)
        imgdata = base64.b64decode(logo)
        filename = 'c'+str(b)+ ".png"  # I assume you have a way of picking unique filenames
        with open(filename, 'wb') as f:
            f.write(imgdata)
            print(b)
    except:
        driver.find_element_by_xpath("//div[@id='captchaRefresh']/div/button/img").click()
        print("error releated to image xpath...logo")
        time.sleep(2)
    b=b+1
    try:
        driver.find_element_by_xpath("//div[@id='captchaRefresh']/div/button/img").click()
        
    except:
        print("error releated to image xpath")
        time.sleep(3)
    time.sleep(0.2)
    x=x+1
    if(x>=1000):
        time.sleep(5)
        print("routine wait")
        x=0