import numpy as np
from PIL import Image
import os
import cv2
from matplotlib import pyplot
from skimage.measure import compare_ssim

#sav='C:\\Users\\vk779\\Desktop\\captcha\\cap\\'
#x=os.getcwd()

def im2tx(grayA):
    lis="123456789ABCDEFGHIJKLMNPQRSTUVWXYZ"
    temp=0
    for x in lis:
        #imageB = "C:/Users/vk779/Desktop/captcha/capa/"+x+".jpg"
        imageB=os.getcwd()+"/data"+x+".jpg"
        grayB = cv2.imread(imageB,0)
        #grayB = cv2.cvtColor(grayB, cv2.COLOR_BGR2GRAY)
        #grayB = np.array(Image.open(imageB).convert('L'))
        (score, diff) = compare_ssim(grayA, grayB, full=True)
        #diff = (diff * 255).astype("uint8")
        if(temp < score):
            temp= score
            ans=x
    return ans
    
def image2txt(path ,show=False): #=(os.getcwd()+"\0.png")
    a = cv2.imread(path) 
    
    if(show == True):
        ax=Image.fromarray(a)
        pyplot.imshow(ax)
        pyplot.show()
    a= cv2.cvtColor(a, cv2.COLOR_BGR2GRAY)
    for i in range(45):
        for j in range(180):
            if(a[i][j]!= 0 and a[i][j]!= 255 ):
                a[i][j]=255
            if(j%30==0 and a[i][j]==0):
                a[i][j]=255 #255 us for white
                for x in range(5):
                    if((j-x)>=0):
                        a[i][j-x]=255

    for i in range(45):
        for j in range(180):           
            if(a[i][j]==0):
                if(i!=0 and j!=0 and i!=44 and j!=179):
                    if(a[i+1][j] ==255 and a[i+1][j+1]==255):
                        if( a[i-1][j] ==255 and a[i][j-1] ==255 and a[i][j+1]==255):
                            if(a[i+1][j-1] ==255 and a[i-1][j+1] ==255 and a[i-1][j-1]==255):
                                a[i][j]=255

    c = (2, 2) 
    new_image = cv2.blur(a,c)

   
    a= np.asarray(new_image)

    for i in range(45):
        for j in range(180):           
            if(a[i][j]<255):
                if( i!=44 and j!=179):
                    if(a[i+1][j] >0 and a[i+1][j+1]>0):
                        if( a[abs(i-1)][j]>0 and a[i][abs(j-1)] >0 and a[i][j+1]>0):
                           # a[i][j]=255
                            if(a[i+1][abs(j-1)]>0 and a[abs(i-1)][j+1]>0 and a[abs(i-1)][j-1]>0):
                                a[i][j]=255
                                #print(i,j,sep="-",end=" ")
                if(i>44 or j>177):
                    a[i][j]=255
    for i in range(45):
        for j in range(180):
            if(a[i][j]<255):
                a[i][j]=0

#    if(show == True):
#        ax=Image.fromarray(a)
#        pyplot.imshow(ax)
#        pyplot.show()
    data=""
    for i in range(0,179,30):
        s= a[10:45, i:i+30]
        data=data+im2tx(s)
    return data

import time
import random
xc = random.randint(0,6500)
start_time = time.time()
#xc=421
xmc=0
sho= True
#print(" ",end=" ")
for i in range(xc-1,xc):
    z='C:\\Users\\vk779\\Desktop\\captcha\\cap-'+str(i) +'.jpg'
    
    print(image2txt(z ,sho))
    xmc=xmc+1
    #print(xmc)
print()
print("--- %s seconds ---" % (time.time() - start_time))    
#print(end="\n\n\n\n")   
print("Made by Vinc3nt all rights reserved" )
