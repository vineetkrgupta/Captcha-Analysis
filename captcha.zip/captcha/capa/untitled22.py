import numpy as np
import cupy as cp
import time
### Numpy and CPU
s = time.time()
x_cpu =  np.random.randint(0, 100, size=(3, 3, 2))
np.ones((1000,1000,200))
print(x_cpu)
x_cpu[1]=x_cpu[2]
print(x_cpu[1])

e = time.time()
print(e - s)
### CuPy and GPU
s = time.time()
x_gpu = cp.ones((1000,1000,200))
print(x_gpu[100][1])
x_gpu = cp.ones((1000,1000,200))
x_gpu =  np.random.randint(0, 100, size=(3, 3, 2))
np.ones((1000,1000,200))
print(x_gpu)
x_gpu[1]=x_gpu[2]
print(x_gpu[1])
#x_gpu = cp.ones((1000,1000,200))
cp.cuda.Stream.null.synchronize()
e = time.time()
print(e - s)