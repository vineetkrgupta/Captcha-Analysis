import numpy as np
x=[0,2,1,3]

print(np.dot(x,.2))