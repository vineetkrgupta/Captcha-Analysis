# import the necessary packages
from skimage.measure import compare_ssim
import argparse

import cv2
imageA = "C:/Users/vk779/Desktop/captcha/capa/33.jpg"
grayA = cv2.imread(imageA)
grayA = cv2.cvtColor(grayA, cv2.COLOR_BGR2GRAY)
# convert the images to grayscale

lis="123456789ABCDEFGHIJKLMNPQRSTUVWXYZ"
temp=0
for x in lis:
    imageB = "C:/Users/vk779/Desktop/captcha/capa/"+x+".jpg"
    #print(imageB)
    grayB = cv2.imread(imageB)
    grayB = cv2.cvtColor(grayB, cv2.COLOR_BGR2GRAY)
    (score, diff) = compare_ssim(grayA, grayB, full=True)
    diff = (diff * 255).astype("uint8")
    if(temp < score):
        temp= score
        ans=x
print(temp, ans , sep="...")